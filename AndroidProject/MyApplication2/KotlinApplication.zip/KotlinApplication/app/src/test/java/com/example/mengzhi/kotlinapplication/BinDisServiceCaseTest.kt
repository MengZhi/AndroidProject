package com.example.mengzhi.kotlinapplication

import org.junit.Test

import org.junit.Assert.*
import org.mockito.Mockito
import java.io.File

class BinDisServiceCaseTest {

    @Test
    fun printClassName() {
        var file : File
        file.canonicalFile

    }

    @Test
    fun bind() {
    }

    @Test
    fun getDisDataManager() {
    }
}