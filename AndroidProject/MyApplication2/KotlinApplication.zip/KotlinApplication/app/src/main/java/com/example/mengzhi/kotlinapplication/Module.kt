package com.example.mengzhi.kotlinapplication

import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module

val helloModule = module {

    single { DisDataManager() as IDisDataManager }

    //factory { BindDisServiceCase(get()) }
}