package com.example.mengzhi.kotlinapplication

import android.content.Context
import android.os.Bundle
import android.preference.PreferenceFragment
import android.support.v4.app.Fragment
import java.util.prefs.PreferencesFactory

class MyFragment : PreferenceFragment {
    constructor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addPreferencesFromResource(R.xml.preference_screen)
    }
}