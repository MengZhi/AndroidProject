package com.example.mengzhi.kotlinapplication

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.preference.PreferenceActivity
import android.preference.PreferenceFragment
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.util.Log
import android.view.View
import kotlinx.coroutines.*
import org.koin.android.viewmodel.ext.android.viewModel
import org.koin.core.KoinComponent
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin
import org.koin.core.get
import org.koin.core.inject
import kotlin.concurrent.fixedRateTimer

class MainActivity : PreferenceActivity() , KoinComponent{

    /**
     * The number of pages (wizard steps) to show in this demo.
     */
    private val NUM_PAGES = 4

    /**
     * The pager widget, which handles animation and allows swiping horizontally to access previous
     * and next wizard steps.
     */
    private var mPager: ViewPager? = null

    /**
     * The pager adapter, which provides the pages to the view pager widget.
     */
    private var pagerAdapter: PagerAdapter? = null

    //val myViewModel: BindDisServiceCase by viewModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        startKoin {
//            printLogger()
//            modules(helloModule)
//        }


//        val fragmentManager = fragmentManager
//        val fragmentTransaction = fragmentManager.beginTransaction()
//        val fragment = MyFragment()
//        fragmentTransaction.replace(R.id.my_fragment, fragment)
//        fragmentTransaction.commit()

        setContentView(R.layout.view_pager_layout)

        // Instantiate a ViewPager and a PagerAdapter.
        mPager = findViewById<View>(R.id.pager) as ViewPager
        pagerAdapter = ScreenSlidePagerAdapter(getSupportFragmentManager())
        mPager.setAdapter(pagerAdapter)






//        Log.d("AA", "协程初始化开始，时间: " + System.currentTimeMillis())
//        GlobalScope.launch(Dispatchers.Unconfined) {
//            Log.d("AA", "协程初始化完成，时间: " + System.currentTimeMillis())
//            for (i in 1..3) {
//                Log.d("AA", "协程任务1打印第$i 次，时间: " + System.currentTimeMillis())
//            }
//            delay(500)
//            for (i in 1..3) {
//                Log.d("AA", "协程任务2打印第$i 次，时间: " + System.currentTimeMillis())
//            }
//        }
//
//        Log.d("AA", "主线程 sleep ，时间: " + System.currentTimeMillis())
//        Thread.sleep(1000)
//        Log.d("AA", "主线程运行，时间: " + System.currentTimeMillis())
//
//        for (i in 1..3) {
//            Log.d("AA", "主线程打印第$i 次，时间: " + System.currentTimeMillis())
//        }



    }

    /**
     * A simple pager adapter that represents 5 ScreenSlidePageFragment objects, in
     * sequence.
     */
    private inner class ScreenSlidePagerAdapter(fm:FragmentManager) : FragmentStatePagerAdapter(fm) {

        override fun getItem(position: Int): Fragment {
            val fragment = ScreenSlidePageFragment()
            val b = Bundle()

            b.putInt("position", position)
            fragment.arguments = b
            return fragment
        }

        override fun getCount(): Int {
            return NUM_PAGES
        }
    }

    override fun onResume() {
        super.onResume()

//        GlobalScope.launch {
//            var res = withTimeoutOrNull(4000) {
//                skillDispatch()
//                "Done"
//            }
//            if (!res.equals("Done")) {
//                Log.d(TAG, "this is final.")
//            }
//        }


    }

    suspend fun skillDispatch() {
//        val disDataManager:IDisDataManager by inject()
//        disDataManager.getDisData(object:IDisDataManager.DisCallback{
//            override fun onResult(res: String) {
//                Log.d(TAG, res)
//            }
//        })

    }

    override fun finish() {
        super.finish()
//        stopKoin()
    }

    companion object {
        val TAG = "zhimeng"
    }
}
