package com.example.mengzhi.kotlinapplication

interface IDisDataManager {
    fun getClassName():String

    fun bindService()

    suspend fun getDisData(callback:DisCallback)

    interface DisCallback {
        fun onResult(res:String)
    }
}