package com.example.mengzhi.kotlinapplication

import android.arch.lifecycle.ViewModel
import android.util.Log
import org.koin.core.KoinComponent
import org.koin.core.inject

class BinDisServiceCase (val disDataManager: IDisDataManager): KoinComponent, ViewModel(){

    fun printClassName(){
        Log.d(TAG, disDataManager.getClassName())
        var newName = "BindDisServiceCase: " + disDataManager.getClassName()
        Log.d(TAG, newName)
    }

    fun bind() {
        Log.d(TAG, "BindDisServiceCase bindService")
        disDataManager.bindService()
    }

    companion object {
        private val TAG = "BindDisServiceCase"
    }
}