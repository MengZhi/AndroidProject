package com.example.mengzhi.kotlinapplication

import android.util.Log
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.lang.Thread.sleep

class DisDataManager : IDisDataManager{
    override fun getClassName(): String {
        Log.d(TAG, "DisDataManager")
        return "DisDataManager"
    }

    override fun bindService() {
        Log.d(TAG, "bindService")
    }

    override suspend fun getDisData(callback: IDisDataManager.DisCallback) {
        Log.d("zhimeng", "start getDisData")
        delay(5000)
        callback.onResult("DIS DisDataManager")
    }

    companion object {
        val TAG = "DisDataManager"
    }
}